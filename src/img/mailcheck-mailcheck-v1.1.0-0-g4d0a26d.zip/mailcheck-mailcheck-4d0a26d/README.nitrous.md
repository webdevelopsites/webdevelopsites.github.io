## Get started on Nitrous.IO

Run the following commands in the terminal below:

1. `cd ~/workspace/mailcheck`
2. `npm install`
3. `./script/server`

Go to the "Preview Menu" and click "Port 3000"
